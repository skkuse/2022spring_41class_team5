const c = `#include<stdio.h>

int main() {
    // Your Code will come here
    return 0;
}
`
 const cpp = `#include<bits/stdc++.h> \nusing namespace std;\n\nint main() {\n\t//Your Code will come here\n\treturn 0;\n}
`

const java = `class test {
    public static void main(String args[]){
        // Your Code will come here
    }
}
`

const python = `
# Your code will come here
def solution():
    answer = 0

    return answer
`

export const code = {
    c, cpp, java, python
}